package com.example.bookapp

import kotlinx.serialization.Serializable

@Serializable
data class Book (
    val id: String,
    val createdAt: Int,
    val bookTitle: String,
    val author: String,
    val price: Double,
    val genre: String

)