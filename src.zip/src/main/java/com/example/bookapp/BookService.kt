package com.example.bookapp


import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.engine.android.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.serialization.json.Json


private const val BASE_URL = "https://6932a11ee5a9e342d2701bb0.mockapi.io/Book"

val bookHttpClient = HttpClient(Android) {
    install(ContentNegotiation) {
        json(Json {
            prettyPrint = true
            isLenient = true
        })
    }
}

class BookService {
    suspend fun getBooks(): List<Book> {
        val response = bookHttpClient.get(BASE_URL)
        return response.body<List<Book>>()
    }
}


